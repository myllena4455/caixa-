# 🚀 SISTEMA PDV - GUIA DE INSTALAÇÃO INFINITYFREE

## 📋 CHECKLIST PRÉ-INSTALAÇÃO

Antes de começar, você precisa ter:
- ✅ Conta criada no InfinityFree (https://infinityfree.net)
- ✅ Site/domínio criado no painel do InfinityFree
- ✅ Acesso ao painel de controle (cPanel)
- ✅ Credenciais do banco de dados MySQL

---

## 🎯 PASSO A PASSO COMPLETO

### **PASSO 1: CRIAR BANCO DE DADOS**

1. **Acesse o cPanel** do seu site no InfinityFree

2. **Localize "MySQL Databases"** e clique nele

3. **Crie um novo banco de dados:**
   - Nome sugerido: `pdv_system` ou qualquer nome
   - Clique em "Create Database"

4. **Crie um usuário MySQL:**
   - Nome: `pdv_user` ou qualquer nome
   - Senha: **Crie uma senha forte** (anote!)
   - Clique em "Create User"

5. **Vincule o usuário ao banco:**
   - Selecione o usuário criado
   - Selecione o banco criado
   - Marque "ALL PRIVILEGES"
   - Clique em "Add"

6. **ANOTE AS CREDENCIAIS:**
   ```
   MySQL Hostname: sql212.infinityfree.com (ou similar)
   MySQL Database: if0_XXXXX_pdv_system
   MySQL Username: if0_XXXXX_pdv_user
   MySQL Password: sua_senha_aqui
   ```

---

### **PASSO 2: IMPORTAR ESTRUTURA DO BANCO**

1. **Acesse phpMyAdmin** no cPanel

2. **Selecione seu banco** na barra lateral esquerda

3. **Clique na aba "SQL"**

4. **Copie TODO o conteúdo** do arquivo `sql/schema.sql`

5. **Cole na caixa de texto** do phpMyAdmin

6. **Clique em "Go"** (ou "Executar")

7. ✅ **Verifique se as tabelas foram criadas:**
   - users
   - stores
   - products
   - sales
   - sale_items

---

### **PASSO 3: CONFIGURAR CONEXÃO DO BANCO**

1. **Abra o arquivo** `config/db.php`

2. **Substitua as credenciais** pelas suas:

```php
<?php
class DB {
    public static function pdo(): PDO {
        static $pdo = null;
        if ($pdo) return $pdo;
        
        // 👇 ALTERE AQUI COM SUAS CREDENCIAIS 👇
        $host = 'sql212.infinityfree.com';      // MySQL Hostname do InfinityFree
        $db   = 'if0_XXXXX_pdv_system';         // MySQL Database Name
        $user = 'if0_XXXXX_pdv_user';           // MySQL Username
        $pass = 'sua_senha_forte_aqui';         // MySQL Password
        // 👆 ALTERE AQUI COM SUAS CREDENCIAIS 👆
        
        $dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
        $opts = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];
        $pdo = new PDO($dsn, $user, $pass, $opts);
        return $pdo;
    }
}
```

3. **Salve o arquivo**

---

### **PASSO 4: FAZER UPLOAD DOS ARQUIVOS**

#### **Opção A: Via File Manager (Mais fácil)**

1. **Acesse "File Manager"** no cPanel

2. **Navegue até a pasta** `htdocs`

3. **Delete tudo** que estiver dentro de `htdocs` (se houver)

4. **Clique em "Upload"** no canto superior direito

5. **Selecione TODOS os arquivos e pastas** do sistema:
   ```
   ├── api/
   │   ├── auth.php
   │   ├── helpers.php
   │   └── index.php
   ├── config/
   │   └── db.php (já configurado)
   ├── css/
   │   └── estilos.css
   ├── js/
   │   └── site.js
   ├── sql/
   │   ├── schema.sql
   │   └── update_schema.sql
   ├── index.html
   └── ilogin.html
   ```

6. **Aguarde o upload** completar (pode demorar alguns minutos)

#### **Opção B: Via FTP (Mais rápido)**

1. **Use um cliente FTP** como FileZilla

2. **Credenciais FTP:**
   - Host: `ftpupload.net` (ou conforme painel)
   - Usuário: seu usuário do InfinityFree
   - Senha: sua senha do InfinityFree
   - Porta: 21

3. **Conecte-se** ao servidor

4. **Navegue até** `/htdocs`

5. **Delete tudo** que estiver lá

6. **Faça upload** de todos os arquivos do sistema

---

### **PASSO 5: TESTAR O SISTEMA**

1. **Acesse seu site:**
   - URL: `http://seusite.infinityfreeapp.com/ilogin.html`
   - Ou: `http://seudominio.com/ilogin.html` (se tiver domínio próprio)

2. **Cadastre o primeiro usuário:**
   - Clique em "Cadastre-se"
   - Preencha:
     - Nome completo
     - E-mail
     - Senha (mínimo 6 caracteres)
     - **Dados da loja** (obrigatório):
       - Nome da Loja
       - Nome do Proprietário
       - Telefone
       - CNPJ (opcional)
       - Endereço
   - Clique em "Cadastrar"

3. **Faça login:**
   - Use o e-mail e senha cadastrados
   - Clique em "Entrar"

4. ✅ **Se aparecer a tela principal** = TUDO CERTO!

---

### **PASSO 6: TESTAR FUNCIONALIDADES**

#### **Teste 1: Cadastrar Produto**
1. Clique em "Novo Item"
2. Preencha:
   - Código: `P001`
   - Nome: `Produto Teste`
   - Custo: `50.00`
   - Preço: `100.00`
   - Estoque: `10`
3. Clique em "Salvar Produto"
4. ✅ Deve aparecer na lista

#### **Teste 2: Fazer uma Venda**
1. Digite `P001` no campo "Cód. do produto"
2. Quantidade: `1`
3. Clique em "Adicionar ao Carrinho"
4. Clique em "Fechar Venda"
5. Selecione "Dinheiro"
6. Valor pago: `100.00`
7. Clique em "Confirmar Venda"
8. ✅ Notinha deve abrir automaticamente

#### **Teste 3: Ver Relatório**
1. Na seção "Resumo do Dia", veja:
   - Vendas Registradas: 1
   - Faturamento Total: R$ 100,00
   - Lucro Estimado: R$ 30,00
2. Clique em "Gerar Relatório PDF"
3. ✅ PDF deve baixar

---

## ⚠️ PROBLEMAS COMUNS E SOLUÇÕES

### **❌ Erro: "Não foi possível conectar ao servidor"**

**Causa:** Credenciais do banco incorretas

**Solução:**
1. Verifique `config/db.php`
2. Confirme as credenciais no painel MySQL do cPanel
3. Certifique-se de usar o hostname correto (ex: `sql212.infinityfree.com`)

---

### **❌ Erro: "Access denied for user"**

**Causa:** Usuário não tem permissão no banco

**Solução:**
1. No cPanel → MySQL Databases
2. Seção "Add User To Database"
3. Selecione o usuário e o banco
4. Marque "ALL PRIVILEGES"
5. Salve

---

### **❌ Página em branco / Erro 500**

**Causa:** Erro de sintaxe PHP ou permissões

**Solução:**
1. Ative exibição de erros temporariamente:
   - Adicione no topo de `api/index.php`:
   ```php
   <?php
   error_reporting(E_ALL);
   ini_set('display_errors', 1);
   ```
2. Recarregue a página e veja o erro
3. Corrija o erro indicado
4. **Remova** as linhas acima depois de corrigir

---

### **❌ Notinha não abre / Popup bloqueado**

**Causa:** Navegador bloqueando popups

**Solução:**
1. Permita popups para seu site
2. Chrome: Ícone de popup na barra de endereço → "Sempre permitir"
3. Firefox: Preferências → Privacidade → Exceções

---

### **❌ Estilo CSS não carrega**

**Causa:** Caminho incorreto ou arquivo não enviado

**Solução:**
1. Verifique se `css/estilos.css` foi enviado
2. Teste acessar: `http://seusite.com/css/estilos.css`
3. Se der erro 404, reenvie o arquivo

---

## 🔒 SEGURANÇA IMPORTANTE

### **Após instalação, faça isso:**

1. **Mude a senha do banco** no cPanel regularmente

2. **Use HTTPS** (InfinityFree oferece SSL grátis):
   - No cPanel → SSL/TLS Status
   - Ative SSL para seu domínio

3. **Não compartilhe** suas credenciais do banco

4. **Faça backup** regularmente:
   - No cPanel → Backup
   - Baixe backup do banco de dados

---

## 📱 ACESSANDO O SISTEMA

### **URLs do Sistema:**

- **Login:** `http://seusite.com/ilogin.html`
- **PDV (após login):** `http://seusite.com/index.html`

### **Primeira Vez:**
1. Sempre acesse `/ilogin.html` primeiro
2. Cadastre-se com dados da sua loja
3. Faça login
4. Sistema redireciona automaticamente

### **Uso Diário:**
1. Acesse `/ilogin.html`
2. Faça login
3. Use o sistema normalmente
4. Clique em "Sair" quando terminar

---

## 👥 GERENCIANDO USUÁRIOS

### **Criar Funcionários (via phpMyAdmin):**

```sql
-- Funcionário (só pode fazer vendas)
INSERT INTO users (name, email, password_hash, role) 
VALUES ('Nome do Funcionário', 'funcionario@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'funcionario');

-- Gerente (pode gerenciar produtos)
INSERT INTO users (name, email, password_hash, role) 
VALUES ('Nome do Gerente', 'gerente@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'gerente');
```

**Senha padrão:** `password`

**Para criar senha customizada:**
1. Acesse: https://bcrypt-generator.com/
2. Digite a senha desejada
3. Cost: 10
4. Copie o hash gerado
5. Use no INSERT acima

---

## 📊 ESTRUTURA DE PASTAS NO SERVIDOR

```
htdocs/
├── api/
│   ├── auth.php          (Autenticação)
│   ├── helpers.php       (Funções auxiliares)
│   └── index.php         (Rotas da API)
├── config/
│   └── db.php            (Configuração do banco) ⚠️ EDITAR AQUI
├── css/
│   └── estilos.css       (Estilos do sistema)
├── js/
│   └── site.js           (Lógica do sistema)
├── sql/
│   ├── schema.sql        (Estrutura do banco - usar 1x)
│   └── update_schema.sql (Atualização - usar se já tem dados)
├── index.html            (Tela principal - PDV)
└── ilogin.html           (Tela de login)
```

**⚠️ NÃO EDITE** outros arquivos além de `config/db.php`!

---

## ✅ CHECKLIST FINAL

Antes de usar em produção, verifique:

- [ ] Banco de dados criado e tabelas importadas
- [ ] Credenciais configuradas em `config/db.php`
- [ ] Todos os arquivos enviados para `/htdocs`
- [ ] Primeiro usuário cadastrado com sucesso
- [ ] Login funcionando
- [ ] Consegue cadastrar produto
- [ ] Consegue fazer venda
- [ ] Notinha imprime corretamente
- [ ] Relatório PDF gera sem erros
- [ ] SSL/HTTPS ativado (recomendado)

---

## 🆘 SUPORTE

### **Se nada funcionar:**

1. **Verifique os logs de erro:**
   - cPanel → Error Logs
   - Últimas linhas mostram o problema

2. **Teste a conexão do banco:**
   - Crie arquivo `test.php` em `/htdocs`:
   ```php
   <?php
   require_once 'config/db.php';
   try {
       $pdo = DB::pdo();
       echo "Conexão OK!";
   } catch (Exception $e) {
       echo "Erro: " . $e->getMessage();
   }
   ```
   - Acesse: `http://seusite.com/test.php`
   - Se der erro, o problema é nas credenciais

3. **Verifique permissões:**
   - Todos os arquivos devem ter permissão 644
   - Todas as pastas devem ter permissão 755

---

## 🎉 PRONTO!

Seu sistema PDV está instalado e funcionando!

**Próximos passos:**
1. Cadastre seus produtos
2. Configure relatórios periódicos
3. Treine sua equipe
4. Comece a vender!

---

**Data de criação:** 21/12/2025  
**Versão:** 1.0  
**Compatível com:** InfinityFree e outros hostings PHP gratuitos
